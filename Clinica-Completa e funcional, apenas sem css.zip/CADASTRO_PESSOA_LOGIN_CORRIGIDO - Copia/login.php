<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

if (tutorLogado() !== null) {
    header('Location: tela_inicial.php');
    exit;
}

$erro = trim((string)($_GET['erro'] ?? ''));
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login - Tutor</title>
<link rel="stylesheet" href="cad.css">
<style>
body{min-height:100vh;margin:0;display:flex;align-items:center;justify-content:center;background:#eef6ff;font-family:Arial,sans-serif}
.login-card{width:min(420px,90%);background:#fff;padding:35px;border-radius:16px;box-shadow:0 8px 30px #0002}
.login-card h1{margin-top:0}.login-card p{text-align:center}.login-card input{width:100%;box-sizing:border-box;padding:13px;margin:7px 0 18px;border:1px solid #ccc;border-radius:7px}
.login-card button{width:100%;padding:13px;border:0;border-radius:7px;background:#ff8c00;color:#fff;font-weight:bold;cursor:pointer}
.erro{background:#ffe5e5;color:#a00000;padding:12px;border-radius:7px;margin-bottom:15px}.links{text-align:center;margin-top:18px}
</style>
</head>
<body>
<main class="login-card">
    <h1>Login do Tutor</h1>
    <p>Entre na sua conta para acessar seus pets e agendamentos.</p>
    <?php if ($erro !== ''): ?><div class="erro"><?= h($erro) ?></div><?php endif; ?>
    <form action="autenticar.php" method="post">
        <label for="email">E-mail</label>
        <input id="email" name="email" type="email" required autocomplete="email">
        <label for="senha">Senha</label>
        <input id="senha" name="senha" type="password" required autocomplete="current-password">
        <button type="submit">Entrar</button>
    </form>
    <div class="links">
        <p>Não possui conta? <a href="cadastro_pessoa.html">Cadastre-se</a></p>
    </div>
</main>
</body>
</html>
