<?php
declare(strict_types=1);
require_once __DIR__ . '/../auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: agendamento.php', true, 303);
    exit;
}

$tutor = exigirLogin();

function erro(string $mensagem): never {
    header('Location: agendamento.php?erro=' . rawurlencode($mensagem), true, 303);
    exit;
}

$pet = trim((string)($_POST['pet'] ?? ''));
$servico = trim((string)($_POST['servico'] ?? ''));
$data = trim((string)($_POST['data'] ?? ''));
$horario = trim((string)($_POST['horario'] ?? ''));

if ($pet === '' || $servico === '' || $data === '' || $horario === '') erro('Preencha todos os campos do agendamento.');

$meusPets = petsDoTutor((string)$tutor['email']);
$petValido = false;
foreach ($meusPets as $petCadastrado) {
    if ((string)($petCadastrado['nome'] ?? '') === $pet) {
        $petValido = true;
        break;
    }
}
if (!$petValido) erro('Esse pet não pertence à sua conta.');

if (!in_array($servico, ['Consulta','Vacinação','Exames'], true)) erro('Serviço inválido.');
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $data)) erro('Data inválida.');
if ($data < date('Y-m-d')) erro('Não é possível agendar para uma data passada.');
if (!in_array($horario, ['08:00','09:00','10:00','11:00','13:00','14:00','15:00','16:00','17:00'], true)) erro('Horário inválido.');

$arquivo = __DIR__ . '/agendamentos.json';
$dados = is_file($arquivo) ? json_decode((string)file_get_contents($arquivo), true) : [];
if (!is_array($dados)) $dados = [];

foreach ($dados as $agendamento) {
    if (($agendamento['data'] ?? '') === $data && ($agendamento['horario'] ?? '') === $horario && ($agendamento['status'] ?? '') !== 'Cancelado') {
        erro('Este horário já está ocupado. Escolha outro horário.');
    }
}

$dados[] = [
    'id' => bin2hex(random_bytes(8)),
    'tutor_nome' => (string)($tutor['nome'] ?? ''),
    'tutor_email' => strtolower((string)($tutor['email'] ?? '')),
    'pet' => $pet,
    'servico' => $servico,
    'data' => $data,
    'horario' => $horario,
    'status' => 'Agendado',
    'criado_em' => date('c'),
];

$json = json_encode($dados, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
if ($json === false || file_put_contents($arquivo, $json . PHP_EOL, LOCK_EX) === false) {
    erro('Não foi possível salvar o agendamento. Verifique as permissões da pasta.');
}

header('Location: agendamento.php?sucesso=1', true, 303);
exit;
