<?php
declare(strict_types=1);
require_once __DIR__ . '/../auth.php';

$tutorLogado = exigirLogin();
$pets = petsDoTutor((string)$tutorLogado['email']);
$petSelecionado = trim((string)($_GET['pet'] ?? ''));
$erro = trim((string)($_GET['erro'] ?? ''));
$sucesso = isset($_GET['sucesso']);

$petNomes = array_values(array_map(static fn($p) => (string)($p['nome'] ?? ''), $pets));
if (!in_array($petSelecionado, $petNomes, true)) {
    $petSelecionado = '';
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Agendamento</title>
<link rel="stylesheet" href="agendamento.css">
<style>.conta{margin-left:auto;color:#fff}.conta a{color:#fff}.mensagem{padding:12px;border-radius:8px;margin-bottom:15px}</style>
</head>
<body>
<header class="cabecalho">
    <div class="all">
        <a href="https://www.unifio.edu.br/home/"><img class="logo" src="../logo_vet.png" alt="Logo Unifio"></a>
        <nav class="menu">
            <a href="../cadastro_pet.php" class="button">Meus Pets</a>
            <a href="../painel_admin.php" class="button">Painel</a>
            <a href="../logout.php" class="button">Sair</a>
        </nav>
        <div class="conta">Olá, <?= h($tutorLogado['nome'] ?? '') ?></div>
    </div>
</header>

<main class="conteudo">
<section class="formulario">
    <h1>Agendar Consulta</h1>
    <?php if ($erro !== ''): ?><div class="mensagem erro"><?= h($erro) ?></div><?php endif; ?>
    <?php if ($sucesso): ?><div class="mensagem sucesso">Agendamento realizado com sucesso!</div><?php endif; ?>

    <?php if (!$pets): ?>
        <div class="mensagem erro">Você ainda não possui pets cadastrados. <a href="../cadastro_pet.php">Cadastre um pet primeiro.</a></div>
    <?php else: ?>
    <form id="agendamento" class="agendamento" action="processa_agendamento.php" method="POST">
        <label>Tutor</label>
        <input type="text" value="<?= h($tutorLogado['nome'] ?? '') ?> (<?= h($tutorLogado['email'] ?? '') ?>)" readonly>

        <label for="pet">Seu pet</label>
        <select id="pet" name="pet" required>
            <option value="">Selecione seu pet</option>
            <?php foreach ($pets as $pet): ?>
                <option value="<?= h($pet['nome'] ?? '') ?>" <?= $petSelecionado === ($pet['nome'] ?? '') ? 'selected' : '' ?>>
                    <?= h($pet['nome'] ?? '') ?> — <?= h($pet['especie'] ?? '') ?>
                </option>
            <?php endforeach; ?>
        </select>

        <label for="servico">Serviço</label>
        <select id="servico" name="servico" required>
            <option value="">Selecione o serviço</option>
            <option value="Consulta">Consulta</option>
            <option value="Vacinação">Vacinação</option>
            <option value="Exames">Exames</option>
        </select>

        <label for="data">Data</label>
        <input id="data" type="date" name="data" min="<?= date('Y-m-d') ?>" required>

        <label for="horario">Horário</label>
        <select id="horario" name="horario" required>
            <option value="">Selecione um horário</option>
            <?php foreach (['08:00','09:00','10:00','11:00','13:00','14:00','15:00','16:00','17:00'] as $hora): ?>
                <option value="<?= $hora ?>"><?= $hora ?></option>
            <?php endforeach; ?>
        </select>

        <button type="submit" class="confirmar">Confirmar Agendamento</button>
    </form>
    <?php endif; ?>
</section>

<section class="horarios">
    <h1>Horários disponíveis</h1>
    <p>Escolha a data e o horário no formulário ao lado.</p>
    <div class="grade-horarios">
        <?php foreach (['08:00','09:00','10:00','11:00','13:00','14:00','15:00','16:00','17:00'] as $hora): ?>
            <button type="button" onclick="document.getElementById('horario').value='<?= $hora ?>'"><?= $hora ?></button>
        <?php endforeach; ?>
    </div>
    <div class="disponivel">Os horários são registrados automaticamente no painel administrativo após a confirmação.</div>
</section>
</main>
</body>
</html>
