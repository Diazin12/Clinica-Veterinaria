<?php
declare(strict_types=1);

$arquivoCadastros = __DIR__ . DIRECTORY_SEPARATOR . 'cadastros.json';
$cadastros = [];

if (is_file($arquivoCadastros)) {
    $conteudo = file_get_contents($arquivoCadastros);
    if ($conteudo !== false && trim($conteudo) !== '') {
        $dados = json_decode($conteudo, true);
        if (is_array($dados)) {
            $cadastros = $dados;
        }
    }
}

$arquivoPets = __DIR__ . DIRECTORY_SEPARATOR . 'pets.json';
$pets = [];
if (is_file($arquivoPets)) {
    $conteudoPets = file_get_contents($arquivoPets);
    if ($conteudoPets !== false && trim($conteudoPets) !== '') {
        $dadosPets = json_decode($conteudoPets, true);
        if (is_array($dadosPets)) $pets = $dadosPets;
    }
}

$arquivoAgendamentos = __DIR__ . DIRECTORY_SEPARATOR . 'AGENDAMENTO' . DIRECTORY_SEPARATOR . 'agendamentos.json';
$agendamentos = [];
if (is_file($arquivoAgendamentos)) {
    $conteudoAgendamentos = file_get_contents($arquivoAgendamentos);
    if ($conteudoAgendamentos !== false && trim($conteudoAgendamentos) !== '') {
        $dadosAgendamentos = json_decode($conteudoAgendamentos, true);
        if (is_array($dadosAgendamentos)) $agendamentos = $dadosAgendamentos;
    }
}

$totalTutores = count($cadastros);
$totalPets = count($pets);
$totalAgendamentos = count(array_filter($agendamentos, static fn($a) => ($a['status'] ?? '') !== 'Cancelado'));
$dataHoje = date('Y-m-d');
$consultasHoje = count(array_filter($agendamentos, static fn($a) => ($a['data'] ?? '') === $dataHoje && ($a['status'] ?? '') !== 'Cancelado'));

function e(mixed $valor): string
{
    return htmlspecialchars((string) $valor, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel do Administrador - UniFio</title>
    <link rel="stylesheet" href="painel_admin.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/7.3.1/css/all.min.css">
</head>
<body>

<header class="topo">
    <div class="logo-area">
        <img src="logo_vet.png" alt="UniFio Clínica Veterinária">
    </div>

    <nav class="menu">
        <a href="tela_inicial.php">Início</a>
        <a href="#">Serviços</a>
        <a href="../AGENDAMENTO/agendamento.html">Agendamentos</a>
        <a href="painel_admin.php" class="ativo">Painel</a>
        <a href="#">Sair</a>
    </nav>
</header>

<main class="container">

    <section class="titulo">
        <div class="icone-titulo">
            <i class="fa-solid fa-calendar-days"></i>
        </div>
        <div>
            <h1>Painel do Administrador</h1>
            <p>Visualize e gerencie as informações da clínica veterinária.</p>
        </div>
    </section>

    <section class="cards">
        <div class="card">
            <div class="card-icone azul">
                <i class="fa-solid fa-calendar-check"></i>
            </div>
            <div>
                <span>Agendamentos</span>
                <strong><?= $totalAgendamentos ?></strong>
            </div>
        </div>

        <div class="card">
            <div class="card-icone azul">
                <i class="fa-solid fa-user"></i>
            </div>
            <div>
                <span>Tutores</span>
                <strong><?= $totalTutores ?></strong>
            </div>
        </div>

        <div class="card">
            <div class="card-icone azul">
                <i class="fa-solid fa-paw"></i>
            </div>
            <div>
                <span>Pets</span>
                <strong><?= $totalPets ?></strong>
            </div>
        </div>

        <div class="card">
            <div class="card-icone laranja">
                <i class="fa-solid fa-stethoscope"></i>
            </div>
            <div>
                <span>Consultas hoje</span>
                <strong><?= $consultasHoje ?></strong>
            </div>
        </div>
    </section>

    <section class="painel">
        <div class="abas">
            <button class="aba" type="button" onclick="mostrarAba('agendamentos', this)">
                <i class="fa-solid fa-calendar"></i> Agendamentos
            </button>
            <button class="aba ativa" type="button" onclick="mostrarAba('tutores', this)">
                <i class="fa-solid fa-user"></i> Tutores
            </button>
            <button class="aba" type="button" onclick="mostrarAba('pets', this)">
                <i class="fa-solid fa-paw"></i> Pets
            </button>
        </div>

        <section id="tutores" class="conteudo-aba">
            <div class="cabecalho">
                <div>
                    <h2>Tutores cadastrados</h2>
                    <p>Dados puxados automaticamente do cadastro de tutores.</p>
                </div>
                <div class="contador">
                    <i class="fa-solid fa-users"></i>
                    <?= $totalTutores ?> tutor(es)
                </div>
            </div>

            <div class="tabela-container">
                <?php if ($totalTutores > 0): ?>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Nome</th>
                                <th>E-mail</th>
                                <th>Telefone</th>
                                <th>Endereço</th>
                                <th>Cadastro</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cadastros as $indice => $tutor): ?>
                                <tr>
                                    <td><?= $indice + 1 ?></td>
                                    <td class="nome-tutor"><?= e($tutor['nome'] ?? '') ?></td>
                                    <td><?= e($tutor['email'] ?? '') ?></td>
                                    <td><?= e($tutor['telefone'] ?? '') ?></td>
                                    <td><?= e($tutor['endereco'] ?? '') ?></td>
                                    <td>
                                        <?php
                                        $dataCadastro = $tutor['criado_em'] ?? '';
                                        if ($dataCadastro !== '') {
                                            $timestamp = strtotime((string) $dataCadastro);
                                            echo $timestamp ? e(date('d/m/Y H:i', $timestamp)) : e($dataCadastro);
                                        } else {
                                            echo '-';
                                        }
                                        ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="vazio">
                        <i class="fa-solid fa-user-plus"></i>
                        <h3>Nenhum tutor cadastrado</h3>
                        <p>Quando alguém realizar um cadastro, as informações aparecerão aqui automaticamente.</p>
                    </div>
                <?php endif; ?>
            </div>
        </section>

        <section id="agendamentos" class="conteudo-aba escondido">
            <div class="cabecalho">
                <div>
                    <h2>Agendamentos</h2>
                    <p>Agendamentos registrados automaticamente pelo sistema.</p>
                </div>
                <div class="contador"><i class="fa-solid fa-calendar-check"></i> <?= $totalAgendamentos ?> agendamento(s)</div>
            </div>
            <div class="tabela-container">
                <?php if ($totalAgendamentos > 0): ?>
                    <table>
                        <thead><tr><th>Data</th><th>Horário</th><th>Tutor</th><th>Pet</th><th>Serviço</th><th>Status</th></tr></thead>
                        <tbody>
                        <?php foreach ($agendamentos as $agendamento): ?>
                            <?php if (($agendamento['status'] ?? '') === 'Cancelado') continue; ?>
                            <tr>
                                <td><?= e(date('d/m/Y', strtotime((string)($agendamento['data'] ?? '')))) ?></td>
                                <td><?= e($agendamento['horario'] ?? '') ?></td>
                                <td class="nome-tutor"><?= e($agendamento['tutor_nome'] ?? '') ?></td>
                                <td><?= e($agendamento['pet'] ?? '') ?></td>
                                <td><?= e($agendamento['servico'] ?? '') ?></td>
                                <td><span class="status-agendado"><?= e($agendamento['status'] ?? '') ?></span></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="vazio"><i class="fa-solid fa-calendar-xmark"></i><h3>Nenhum agendamento cadastrado</h3><p>Quando um agendamento for confirmado, ele aparecerá aqui automaticamente.</p></div>
                <?php endif; ?>
            </div>
        </section>

        <section id="pets" class="conteudo-aba escondido">
            <div class="cabecalho">
                <div>
                    <h2>Pets</h2>
                    <p>Área reservada para os pets.</p>
                </div>
            </div>
            <div class="tabela-container">
                <?php if ($totalPets > 0): ?>
                    <table>
                        <thead><tr><th>Pet</th><th>Espécie</th><th>Raça</th><th>Idade</th><th>Peso</th><th>Tutor</th></tr></thead>
                        <tbody>
                        <?php foreach ($pets as $pet): ?>
                            <tr>
                                <td class="nome-tutor"><?= e($pet['nome'] ?? '') ?></td>
                                <td><?= e($pet['especie'] ?? '') ?></td>
                                <td><?= e($pet['raca'] ?? '') ?></td>
                                <td><?= e($pet['idade'] ?? '') ?></td>
                                <td><?= e($pet['peso'] ?? '') ?> kg</td>
                                <td><?= e($pet['tutor_email'] ?? '') ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="vazio"><i class="fa-solid fa-paw"></i><h3>Nenhum pet cadastrado</h3><p>Quando um tutor cadastrar um pet, ele aparecerá aqui.</p></div>
                <?php endif; ?>
            </div>
        </section>
    </section>
</main>

<footer>
    <div class="logo-footer">
        <img src="Unifio-Logo-Branco-800x259.webp" alt="UniFio">
        <small>Centro Universitário das Faculdades Integradas de Ourinhos</small>
    </div>
</footer>

<script>
function mostrarAba(id, botao) {
    document.querySelectorAll('.conteudo-aba').forEach(function (aba) {
        aba.classList.add('escondido');
    });

    document.querySelectorAll('.aba').forEach(function (item) {
        item.classList.remove('ativa');
    });

    document.getElementById(id).classList.remove('escondido');
    botao.classList.add('ativa');
}
</script>

</body>
</html>
