<?php
require_once __DIR__ . '/auth.php';
header('Location: tela_inicial.php');
exit;
