
<?php

require_once __DIR__ . '/auth.php';

$tutor = tutorLogado();

$logado = ($tutor !== null);

$nomeUsuario = '';

if ($logado) {
    $nomeUsuario = (string)($tutor['nome'] ?? 'Tutor');
}

?>

<!DOCTYPE html>
<html lang="pt-br">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>UNIFIO Veterinária</title>

    <link rel="stylesheet" href="tela_ini.css">

</head>

<body>

<header class="cabecalho">

    <div class="all">

        <!-- LOGO -->
        <a href="tela_inicial.php">

            <img
                class="logo"
                src="logo_vet.png"
                alt="Logo UNIFIO"
            >

        </a>


        <!-- MENU -->
        <nav class="menu">

            <a href="tela_inicial.php" class="button">
                Início
            </a>

            <a href="#servicos" class="button">
                Serviços
            </a>

            <a href="AGENDAMENTO/agendamento.php" class="button">
                Agendamentos
            </a>

        </nav>


        <!-- ÁREA DA CONTA -->
        <?php if ($logado): ?>

            <div class="conta-logada">

                <span class="nome-usuario">
                    Olá, <?= h($nomeUsuario) ?>
                </span>

                <a href="logout.php" class="ent">
                    Sair
                </a>

            </div>

        <?php else: ?>

            <a href="login.php" class="ent">
                Entrar
            </a>

        <?php endif; ?>

    </div>

</header>


<!-- FUNDO DA PÁGINA -->

<section class="menu1">

    <img
        src="ChatGPT Image 6 de set. de 2026, 17_32_29.png"
        class="animais"
        alt="Animais recebendo cuidados veterinários"
    >

</section>


<!-- INFORMAÇÕES PRINCIPAIS -->

<section class="info">

    <h1>
        O cuidado que<br>
        seu pet merece!
    </h1>

    <p>
        Seu pet em boas mãos.<br>
        Traga seu pet para a UNIFIO!
    </p>

    <a
        class="agendar-link"
        href="AGENDAMENTO/agendamento.php"
    >
        Agendar consulta
    </a>

</section>


<!-- SERVIÇOS -->

<section class="servicos" id="servicos">


    <!-- CONSULTAS -->

    <div class="card">

        <div class="ic" aria-hidden="true">

            <svg
                viewBox="0 0 64 64"
                focusable="false"
            >

                <path d="M14 10v13a10 10 0 0 0 20 0V10M9 10h10M29 10h10M24 33v6a12 12 0 0 0 24 0v-3"/>

                <circle
                    cx="48"
                    cy="30"
                    r="6"
                />

                <path d="M48 45v8"/>

            </svg>

        </div>

        <h2>
            Consultas
        </h2>

        <p>
            Atendimento veterinário<br>
            com qualidade.
        </p>

    </div>


    <!-- VACINAÇÃO -->

    <div class="card">

        <div class="ic" aria-hidden="true">

            <svg
                viewBox="0 0 64 64"
                focusable="false"
            >

                <path d="m17 47 30-30M13 51l8-8M42 12l10 10M37 17l10 10M22 32l10 10M18 36l10 10M14 40l10 10M47 7l10 10M9 55l6-6"/>

            </svg>

        </div>

        <h2>
            Vacinação
        </h2>

        <p>
            Proteção para todas<br>
            as idades.
        </p>

    </div>


    <!-- EXAMES -->

    <div class="card">

        <div class="ic" aria-hidden="true">

            <svg
                viewBox="0 0 64 64"
                focusable="false"
            >

                <path d="M32 34c-7-8-19-3-19 6 0 5 5 7 10 7h18c5 0 10-2 10-7 0-9-12-14-19-6Z"/>

                <ellipse
                    cx="13"
                    cy="26"
                    rx="5"
                    ry="7"
                    transform="rotate(-25 13 26)"
                />

                <ellipse
                    cx="25"
                    cy="17"
                    rx="5"
                    ry="7"
                    transform="rotate(-10 25 17)"
                />

                <ellipse
                    cx="39"
                    cy="17"
                    rx="5"
                    ry="7"
                    transform="rotate(10 39 17)"
                />

                <ellipse
                    cx="51"
                    cy="26"
                    rx="5"
                    ry="7"
                    transform="rotate(25 51 26)"
                />

            </svg>

        </div>

        <h2>
            Exames
        </h2>

        <p>
            Diagnóstico preciso<br>
            e confiável.
        </p>

    </div>


</section>

</body>

</html>
