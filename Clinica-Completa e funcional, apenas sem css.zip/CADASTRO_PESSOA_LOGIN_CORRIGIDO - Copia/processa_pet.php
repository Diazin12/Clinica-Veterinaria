<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: cadastro_pet.php', true, 303);
    exit;
}

$tutor = exigirLogin();
$pet = [
    'id' => bin2hex(random_bytes(8)),
    'tutor_email' => strtolower((string)$tutor['email']),
    'nome' => trim((string)($_POST['pet'] ?? '')),
    'especie' => trim((string)($_POST['especie'] ?? '')),
    'raca' => trim((string)($_POST['raca'] ?? '')),
    'idade' => trim((string)($_POST['idade'] ?? '')),
    'peso' => trim((string)($_POST['peso'] ?? '')),
    'observacao' => trim((string)($_POST['obs'] ?? '')),
    'criado_em' => date('c')
];

foreach (['nome','especie','raca','idade','peso'] as $campo) {
    if ($pet[$campo] === '') {
        http_response_code(422);
        exit('Erro: preencha todos os campos obrigatórios. <a href="cadastro_pet.php">Voltar</a>');
    }
}
if (!in_array($pet['especie'], ['cachorro','gato','outro'], true)) {
    http_response_code(422);
    exit('Erro: espécie inválida.');
}
foreach ($pet as $campo => $valor) {
    $pet[$campo] = trim(str_replace(['|', "\r", "\n"], ['/', ' ', ' '], (string)$valor));
    if (strlen($pet[$campo]) > 500) {
        http_response_code(422);
        exit('Erro: campo muito longo.');
    }
}

$pets = carregarPets();
$pets[] = $pet;

if (!salvarPets($pets)) {
    http_response_code(500);
    exit('Erro: não foi possível salvar o cadastro. Verifique as permissões da pasta.');
}

header('Location: AGENDAMENTO/agendamento.php?pet=' . rawurlencode($pet['nome']), true, 303);
exit;
