<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

const CADASTROS_FILE = __DIR__ . '/cadastros.json';
const PETS_FILE = __DIR__ . '/pets.json';

function h(mixed $valor): string {
    return htmlspecialchars((string)$valor, ENT_QUOTES, 'UTF-8');
}

function carregarCadastros(): array {
    if (!is_file(CADASTROS_FILE)) return [];
    $dados = json_decode((string)file_get_contents(CADASTROS_FILE), true);
    return is_array($dados) ? $dados : [];
}

function buscarTutorPorEmail(string $email): ?array {
    $email = strtolower(trim($email));
    foreach (carregarCadastros() as $tutor) {
        if (strtolower((string)($tutor['email'] ?? '')) === $email) {
            return $tutor;
        }
    }
    return null;
}

function tutorLogado(): ?array {
    if (empty($_SESSION['tutor_email'])) return null;
    return buscarTutorPorEmail((string)$_SESSION['tutor_email']);
}

function exigirLogin(): array {
    $tutor = tutorLogado();
    if ($tutor === null) {
        header('Location: login.php?erro=' . rawurlencode('Faça login para continuar.'));
        exit;
    }
    return $tutor;
}

function carregarPets(): array {
    if (!is_file(PETS_FILE)) return [];
    $dados = json_decode((string)file_get_contents(PETS_FILE), true);
    return is_array($dados) ? $dados : [];
}

function salvarPets(array $pets): bool {
    $json = json_encode($pets, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    return $json !== false && file_put_contents(PETS_FILE, $json . PHP_EOL, LOCK_EX) !== false;
}

function petsDoTutor(string $email): array {
    $email = strtolower(trim($email));
    return array_values(array_filter(carregarPets(), static function($pet) use ($email) {
        return strtolower((string)($pet['tutor_email'] ?? '')) === $email;
    }));
}
