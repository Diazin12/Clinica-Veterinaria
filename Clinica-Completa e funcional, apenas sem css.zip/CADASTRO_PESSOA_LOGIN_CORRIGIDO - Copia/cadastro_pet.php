<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

$tutor = exigirLogin();
$meusPets = petsDoTutor((string)$tutor['email']);
$sucesso = isset($_GET['cadastro']) && $_GET['cadastro'] === 'sucesso';
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Cadastro de Pet</title>
<link rel="stylesheet" href="cadastro_pet.css">
<style>
.conta{display:flex;gap:15px;align-items:center;margin-left:auto;color:#fff}
.conta a{color:#fff;text-decoration:none}.mensagem{padding:12px;border-radius:8px;margin-bottom:15px;background:#e7f8ed;color:#176b37}
.lista-pets{margin-top:25px}.pet-item{background:#f5f7fa;border-radius:10px;padding:12px;margin:8px 0}
</style>
</head>
<body>
<header class="cabecalho">
  <div class="topo">
    <a href="tela_inicial.php"><img src="logo_vet.png" class="logo" alt="Logo Unifio"></a>
    <nav>
      <a href="tela_inicial.php">Início</a>
      <a href="AGENDAMENTO/agendamento.php">Agendamento</a>
      <a href="painel_admin.php">Painel</a>
      <a href="logout.php">Sair</a>
    </nav>
    <div class="conta">Olá, <?= h($tutor['nome'] ?? '') ?></div>
  </div>
</header>
<main class="container">
  <section class="card">
    <div class="titulo"><div class="icone">🐾</div><div><h1>Cadastro do Pet</h1><p>Cadastre um animal na sua própria conta.</p></div></div>

    <?php if ($sucesso): ?><div class="mensagem">Conta criada e login realizado. Agora cadastre seu pet.</div><?php endif; ?>

    <form action="processa_pet.php" method="POST">
      <div class="grid">
        <div class="campo grande">
          <label>Tutor</label>
          <input type="text" value="<?= h($tutor['nome'] ?? '') ?> (<?= h($tutor['email'] ?? '') ?>)" readonly>
        </div>
        <div class="campo"><label for="pet">Nome do pet</label><input id="pet" name="pet" type="text" maxlength="100" required placeholder="Ex.: Rex"></div>
        <div class="campo"><label for="especie">Espécie</label><select id="especie" name="especie" required><option value="">Selecione</option><option value="cachorro">Cachorro</option><option value="gato">Gato</option><option value="outro">Outro</option></select></div>
        <div class="campo"><label for="raca">Raça</label><input id="raca" name="raca" type="text" maxlength="100" required placeholder="Ex.: Golden Retriever"></div>
        <div class="campo"><label for="idade">Idade</label><input id="idade" name="idade" type="text" maxlength="30" required placeholder="Ex.: 3 anos"></div>
        <div class="campo"><label for="peso">Peso (kg)</label><input id="peso" name="peso" type="number" min="0" step="0.01" required placeholder="Ex.: 12,5"></div>
        <div class="campo grande"><label for="obs">Observações</label><textarea id="obs" name="obs" maxlength="500" placeholder="Alguma informação importante sobre o pet..."></textarea></div>
      </div>
      <div class="acoes"><a href="tela_inicial.php" class="voltar">Voltar</a><button type="submit">Cadastrar Pet</button></div>
    </form>

    <div class="lista-pets">
      <h2>Meus pets</h2>
      <?php if (!$meusPets): ?>
        <p>Você ainda não possui pets cadastrados.</p>
      <?php else: foreach ($meusPets as $pet): ?>
        <div class="pet-item"><strong><?= h($pet['nome']) ?></strong> — <?= h($pet['especie']) ?>, <?= h($pet['raca']) ?>, <?= h($pet['idade']) ?>, <?= h($pet['peso']) ?> kg</div>
      <?php endforeach; endif; ?>
    </div>
  </section>
</main>
</body>
</html>
