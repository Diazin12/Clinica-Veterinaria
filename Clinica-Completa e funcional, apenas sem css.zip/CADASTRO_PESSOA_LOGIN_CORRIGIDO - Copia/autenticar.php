<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: login.php');
    exit;
}

$email = strtolower(trim((string)($_POST['email'] ?? '')));
$senha = (string)($_POST['senha'] ?? '');
$tutor = buscarTutorPorEmail($email);

if ($tutor === null || !password_verify($senha, (string)($tutor['senha_hash'] ?? ''))) {
    header('Location: login.php?erro=' . rawurlencode('E-mail ou senha incorretos.'));
    exit;
}

session_regenerate_id(true);
$_SESSION['tutor_email'] = strtolower((string)$tutor['email']);
header('Location: tela_inicial.php');
exit;
